<footer class="section-p1">
        <div class="col">
            <img class="logo" src="image/logo - Copy.jpg">
            <h4>Contact</h4>
            <p><strong>Address:</strong>panauti-9,Bhandarigaun,kavrepalanchok</p>
            <p><strong>Phone:</strong>+9779803385534</p>
            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
                <h4>About</h4>
                <a href="#">About us</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms and Condition</a>
                <a href="#">Contact us</a>
         </div>

          <div class="col">
                <h4>My Account</h4>
                <a href="#">Sign in</a>
                <a href="#">view Cart</a>
                <a href="#">help</a>
        </div>
    </footer>
</body>
</html>